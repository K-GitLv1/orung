<?php
$host = "localhost";
$user = "66309010034db";
$password = "66309010034";
$database = "66309010034db"; 

// เชื่อมต่อฐานข้อมูล
$connect = new mysqli($host, $user, $password, $database);

// ตั้งค่าการเข้ารหัส
if (!$connect->set_charset("utf8mb4")) {
    die("Error loading character set utf8mb4: " . $connect->error);
}

// ตรวจสอบการเชื่อมต่อ
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
}
?>
