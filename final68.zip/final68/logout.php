<?php
session_start();
session_destroy(); // ลบข้อมูล session
header("Location: ./index.php"); // กลับไปที่หน้า Login
exit();
?>
