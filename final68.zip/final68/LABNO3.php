<html>
<head>
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/table.css">
</head>

<?php
include './header.php'; // รวมไฟล์ header.php
include './dbcon.php'; // เชื่อมต่อฐานข้อมูล

$sql = "SELECT Id, CONCAT(fname, Name) AS full_name, lname, 
        (midt + final) AS total, 
        CASE
            WHEN (midt + final) <= 49 THEN 0
            WHEN (midt + final) <= 59 THEN 1
            WHEN (midt + final) <= 69 THEN 2
            WHEN (midt + final) <= 79 THEN 3
            ELSE 4
        END AS grade
        FROM it53";

$result = mysqli_query($connect,$sql);

if (mysqli_num_rows($result) > 0) {
    echo "<h2>รายงานผลการเรียน</h2>";
    echo "<table border='1'>
            <tr>
                <th>รหัสนักศึกษา</th>
                <th>ชื่อ</th>
                <th>นามสกุล</th>
                <th>คะแนนรวม</th>
                <th>ผลการเรียน</th>
                <th>แก้ไข</th>
                <th>ลบ</th>
            </tr>";

    // ลูปแสดงข้อมูลจากฐานข้อมูล
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>{$row['Id']}</td>
                <td>{$row['full_name']}</td>
                <td>{$row['lname']}</td>
                <td>{$row['total']}</td>
                <td>{$row['grade']}</td>
                <td>
                    <form method='POST' action='edit_form.php'>
                        <input type='hidden' name='id' value='{$row['Id']}'>
                        <button type='submit' class='e'>แก้ไข</button>
                    </form>
                </td>
                <td>
                    <form method='POST' action='delete.php'>
                        <input type='hidden' name='id' value='{$row['Id']}'>
                        <button type='submit' class='d'>ลบ</button>
                    </form>
                </td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "ไม่มีข้อมูล!";
}

// ปิดการเชื่อมต่อหลังจากการใช้งานทั้งหมดเสร็จสิ้น
$connect->close();
?>

</html>
