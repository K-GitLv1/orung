<?php
session_start();
if (isset($_SESSION['username'])) {
    // หากเข้าสู่ระบบแล้ว ให้เปลี่ยนไปหน้า home.php
    header("Location: home.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เข้าสู่ระบบ</title>
    <style>
        /* สไตล์ของ body */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f1f1f1; /* พื้นหลังสีเทาอ่อน */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333; /* ข้อความสีดำ */
        }

        /* สไตล์ของฟอร์ม */
        .login-form {
            background-color: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
            margin-top: 20px;
            opacity: 0;
            animation: fadeIn 0.8s forwards;
        }

        /* การแอนิเมชั่นของฟอร์ม */
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        h2 {
            color: #333; /* สีดำ */
            margin-bottom: 30px;
            font-size: 28px;
            font-weight: 600;
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-size: 16px;
            color: #555; /* สีเทา */
            text-align: left;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 14px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            background-color: #fafafa;
            transition: border-color 0.3s ease, transform 0.3s ease;
        }

        input[type="text"]:focus, input[type="password"]:focus {
            border-color: #d32f2f; /* เปลี่ยนสีขอบเป็นแดงเมื่อโฟกัส */
            background-color: #fff;
            transform: scale(1.05); /* ขยายขนาดเล็กน้อยเมื่อโฟกัส */
        }

        button {
            width: 100%;
            padding: 14px;
            background-color: #d32f2f; /* สีแดง */
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        button:hover {
            background-color: #b71c1c; /* สีแดงเข้มเมื่อ hover */
            transform: translateY(-3px); /* ยกปุ่มขึ้นเล็กน้อยเมื่อ hover */
        }

        .forgot-password {
            display: block;
            margin-top: 15px;
            color: #d32f2f; /* สีแดง */
            font-size: 14px;
            text-decoration: none;
        }

        .forgot-password:hover {
            text-decoration: underline;
        }

        /* สไตล์ของโลโก้ */
        .logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            margin-bottom: 30px;
            animation: logoBounce 1s ease-in-out infinite; /* เพิ่มการเด้งของโลโก้ */
        }

        /* การแอนิเมชั่นของโลโก้ */
        @keyframes logoBounce {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px);
            }
        }
    </style>
</head>
<body>
    <div class="login-form">
        <div class="logo">
            <img src="pic.jpg" alt="Logo"> <!-- เปลี่ยนเป็นโลโก้ของคุณ -->
        </div>
        <h2>เข้าสู่ระบบ</h2>
        <form action="login_process.php" method="post">
            <label>ชื่อผู้ใช้:</label>
            <input type="text" name="username" required><br>

            <label>รหัสผ่าน:</label>
            <input type="password" name="password" required><br>

            <button type="submit">เข้าสู่ระบบ</button>
        </form>

    </div>
</body>
</html>
