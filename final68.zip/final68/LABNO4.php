
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ค้นหาข้อมูลนักศึกษา</title>
    <link rel="stylesheet" href="css/header.css">
</head>
<body>
<?php include 'header.php'; ?>
    <h2>ค้นหาข้อมูลนักศึกษา</h2>
    <form method="post" action="">
        <label>กรุณาป้อนรหัสนักศึกษา: </label>
        <input type="text" name="id" required>
        <button type="submit">ค้นหา</button>
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        include './dbcon.php';  // เชื่อมต่อฐานข้อมูล

        // รับค่ารหัสนักศึกษาจากฟอร์ม
        $id = $_POST['id'];

        // คำสั่ง SQL ค้นหาข้อมูลนักศึกษา
        $sql = "SELECT * FROM it53 WHERE Id = ?";
        $stmt = $connect->prepare($sql);
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        // ตรวจสอบผลลัพธ์
        if ($result->num_rows > 0) {
            echo "<h3>ผลการค้นหา:</h3>";
            echo "<table border='1' cellspacing='0' cellpadding='5'>
                    <tr>
                        <th>รหัสนักศึกษา</th>
                        <th>คำนำหน้า</th>
                        <th>ชื่อ</th>
                        <th>สกุล</th>
                        <th>คะแนนระหว่างภาค</th>
                        <th>คะแนนปลายภาค</th>
                    </tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['Id']}</td>
                        <td>{$row['fname']}</td>
                        <td>{$row['Name']}</td>
                        <td>{$row['lname']}</td>
                        <td>{$row['midt']}</td>
                        <td>{$row['final']}</td>
                      </tr>";
            }
            echo "</table>";
        } else {
            echo "<p style='color:red;'>ไม่พบข้อมูลนักศึกษาที่คุณค้นหา</p>";
        }

        // ปิดการเชื่อมต่อ
        $stmt->close();
        $connect->close();
    }
    ?>
</body>
