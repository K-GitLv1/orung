<?php
// เชื่อมต่อฐานข้อมูล
include './dbcon.php'; 

// รับค่า ID จาก URL
if (isset($_POST['id'])) {
    $id = $_POST['id'];
    
    // ดึงข้อมูลจากฐานข้อมูล
    $sql = "SELECT * FROM it53 WHERE Id = '$id'";
    $result = mysqli_query($connect, $sql);
    $row = mysqli_fetch_assoc($result);
}
?>

<html>
<head>
    <meta charset="UTF-8">
    <title>โปรแกรมบันทึกผลการเรียน</title>
    <link rel="stylesheet" href="./css/header.css"> <!-- ไฟล์ที่เกี่ยวกับ header -->
    <link rel="stylesheet" href="./css/main.css"> <!-- ไฟล์ที่เกี่ยวกับเนื้อหาหลัก -->
</head>
<body>
    <?php require('./header.php'); ?>
    <div class="form-container"> <!-- ใช้ class สำหรับฟอร์ม -->
        <form action="edit.php" method="post">
            <div class="card-header p-4">
                <h2>โปรแกรมบันทึกผลการเรียน</h2>
            </div>

            <!-- กรอก ID นักศึกษา -->
            <label>รหัสนักศึกษา: </label>
            <input type="text" name="id" value="<?php echo $row['Id']; ?>" required><br>

            <!-- ชื่อ -->
            <label>ชื่อ:</label>
            <input type="text" name="fname" value="<?php echo $row['fname']; ?>" required><br>

            <!-- สกุล -->
            <label>สกุล:</label>
            <input type="text" name="lname" value="<?php echo $row['lname']; ?>" required><br>

            <!-- คะแนนระหว่างภาค -->
            <label>คะแนนระหว่างภาค: </label>
            <input type="number" name="midt" value="<?php echo $row['midt']; ?>" required><br>

            <!-- คะแนนปลายภาค -->
            <label>คะแนนปลายภาค: </label>
            <input type="number" name="final" value="<?php echo $row['final']; ?>" required><br>

            <!-- ปุ่มบันทึก -->
            <button type="submit">บันทึกข้อมูล</button>
            <button type="reset">ยกเลิก</button>
        </form>
    </div>
</body>
</html>
