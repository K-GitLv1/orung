<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>report1.php</title>
</head>

<body>
<p>
<?php
	include("connectdb.php");
	$sql = "SELECT * FROM studentit";
	$query = mysql_query($sql);
?>
<table width="100%" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td width="46%" bgcolor="#CCCCCC"><div align="center">รหัสนักศึกษา</div></td>
    <td width="32%" bgcolor="#CCCCCC"><div align="center">ชื่อ</div></td>
    <td width="22%" bgcolor="#CCCCCC"><div align="center">สกุล</div></td>
  </tr>
<?php
	while($result = mysql_fetch_array($query)){
   	$no =  $result['std_no'];
   	$fname = $result['std_fname'];
   	$lname = $result['std_lname'];
   	echo "<tr>
    	<td> $no</td>
    	<td> $fname</td>
    	<td>$lname</td>
   </tr>";
}
	mysql_close();   // ยกเลิกการเชื่อมต่อฐานข้อมูล
?>
</table>
</body>
</html>
