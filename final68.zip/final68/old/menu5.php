<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/mytemplate1.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Untitled Document</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
<style type="text/css">
body,td,th {
	font-family: "MS Serif", "New York", serif;
	font-size: 16px;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a {
	font-family: "MS Serif", "New York", serif;
	font-size: 16px;
}
a:link {
	text-decoration: none;
	color: #000;
}
a:visited {
	text-decoration: none;
	color: #000;
}
a:hover {
	text-decoration: none;
	color: #000;
}
a:active {
	text-decoration: none;
	color: #000;
}
</style>
</head>

<body text="#000" link="#000" vlink="#000" alink="#000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<?php  
   session_start();
	if (!isset($_SESSION['session_user'])) {
		echo 'Please log in!.';
		header('refresh:2;index.php');
	}else{ 
?>
<table width="1200" border="1" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="180" colspan="3" bgcolor="#0099FF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td height="150" colspan="2" bgcolor="#FF6633">&nbsp;</td>
            </tr>
          <tr>
            <td width="92%" height="30">ผู้ใช้งานขณะนี้คือ: <!-- InstanceBeginEditable name="myuser" --><!-- InstanceEndEditable --> <?php echo $_SESSION['session_user'];  ?></td>
            <td width="8%" height="30"><a href="logout.php">Logout</a></td>
          </tr>
        </table></td>
        </tr>
      <tr>
        <td width="25%" height="450" valign="top" bgcolor="#CCCCCC"><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td width="12%">&gt;&gt;</td>
            <td width="88%"><a href="index1.php">หน้าแรก</a></td>
          </tr>
          <tr>
            <td>&gt;&gt;</td>
            <td><a href="menu1.php">รายงานข้อมูล</a></td>
          </tr>
          <tr>
            <td>&gt;&gt;</td>
            <td><a href="menu2.php">เพิ่มข้อมูล</a></td>
          </tr>
          <tr>
            <td>&gt;&gt;</td>
            <td><a href="menu3.php">ลบข้อมูล</a></td>
          </tr>
          <tr>
            <td>&gt;&gt;</td>
            <td><a href="menu4.php">แก้ไขข้อมูล</a></td>
          </tr>
          <tr>
            <td>&gt;&gt;</td>
            <td>ค<a href="menu5.php">้นหาข้อมูล</a></td>
          </tr>
        </table></td>
        <td width="50%" height="450" valign="top"><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="450" valign="top"><!-- InstanceBeginEditable name="data" -->
              <h3 align="center">ค้นหาข้อมูล</h3>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
            <!-- InstanceEndEditable --></td>
          </tr>
        </table></td>
        <td width="25%" height="450" valign="top">&nbsp;</td>
      </tr>
      <tr>
        <td height="150" colspan="3" bgcolor="#FF6633">&nbsp;</td>
        </tr>
    </table></td>
  </tr>
</table>
<?php
  }
?>
</body>
<!-- InstanceEnd --></html>
