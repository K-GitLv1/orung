<?php
	include("connectdb.php");
	$no = $_POST['no'];
	$sql = "SELECT * FROM studentit WHERE std_no LIKE '%$no%'";
	$query = mysql_query($sql);
	$total = mysql_num_rows($query);
	if($total==0){
		echo "ไม่พบข้อมูล!! ";
		header('refresh:2; menu5.php');
		//exit(0);
	}else{
	 while($result = mysql_fetch_array($query)){
   		$no =  $result['std_no'];
   		$fname = $result['std_fname'];
   		$lname = $result['std_lname'];
   		echo $no;
   		echo $fname;
   		echo $lname;
   		echo "<br/>";
	}   // end while
	echo "<br/><hr/>";
	echo "ค้นพบข้อมูลทั้งสิ้น = $total รายการ";
	echo "<br/><hr/>";
	mysql_close();   // ยกเลิกการเชื่อมต่อฐานข้อมูล	
	}   // end else
?>
