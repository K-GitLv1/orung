<form id="form1" name="form1" method="post" action="menu5_2.php">
  กรุณาพิมพ์รหัสนักศึกษา : 
  <label for="no"></label>
  <input type="text" name="no" id="no" />
  <input type="submit" name="send" id="send" value=" ค้นหา " />
</form>
 
