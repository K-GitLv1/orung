<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>check_login.php</title>
</head>

<body>
<?php
session_start();
$user = $_POST['user'];
$pass = $_POST['pass'];
$user_check="admin";
$pass_check="12345";
if(($user==$user_check)&&($pass==$pass_check)){
		$_SESSION['session_user']="$user"; 	//	สร้างตัวแปร session ชื่อ session_user
		$_SESSION['session_pass']="$pass"; 	//	สร้างตัวแปร session ชื่อ session_pass
		header('refresh:0; index1.php');
}else{
		echo " กรุณาตรวจสอบชื่อหรือรหัสผ่านใหม่..!!";
		header('refresh:2; index.php');
}


?>
</body>
</html>