<h1 p align ='center'>PHP67</h1>
<hr size = '20' color = blue>
<?php
	echo("Jiraphat Nurach");
?>
<hr size = '20' color = blue>