<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>report1.php</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
</form>
<p>
<?php
	include("connectdb.php");
	$sql = "SELECT * FROM studentit";
	$query = mysql_query($sql);
?>
<table width="100%" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td bgcolor="#999999"><div align="center">รหัส</div></td>
    <td bgcolor="#999999"><div align="center">ชื่อ</div></td>
    <td bgcolor="#999999"><div align="center">สกุล</div></td>
  </tr>
<?php
   while($result = mysql_fetch_array($query)){
   $no =  $result['std_no'];
   $fname = $result['std_fname'];
   $lname = $result['std_lname'];
/*   echo $no;
   echo $fname;
   echo $lname;
   echo "<br/>";
*/
  echo"  <tr>
    <td>$no</td>
    <td>$fname</td>
    <td>$lname</td>
  </tr>";
}
  mysql_close();   // ยกเลิกการเชื่อมต่อฐานข้อมูล
?>
</table>
</body>
</html>