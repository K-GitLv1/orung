<?php
$host = "localhost";//
$user = "root";
$password= "123456789";
$database = "udtc";
?>
<?php 
     $connect =  new mysqli($host,$user,$password,$database);
     if ($connect->connect_error)
     {
        die ($connect->connect_error);
     }
     else 
     {
        echo "Connection successfully<br/>";
     }
?>