<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
body,td,th {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 16px;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 16px;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
</style>
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<form id="form1" name="form1" method="post" action="check_login.php">
  <p>&nbsp;</p>
  <table width="500" border="1" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td colspan="2" bgcolor="#0099FF"><div align="center">
            <h3>กรุณา Login เพื่อเข้าสู่ระบบ</h3>
          </div></td>
        </tr>
        <tr>
          <td width="37%" height="20">&nbsp;</td>
          <td width="63%" height="20">&nbsp;</td>
        </tr>
        <tr>
          <td height="20"><blockquote>
            <p>Username</p>
          </blockquote></td>
          <td height="20"><label for="user"></label>
            <input type="text" name="user" id="user" /></td>
        </tr>
        <tr>
          <td height="5">&nbsp;</td>
          <td height="5">&nbsp;</td>
        </tr>
        <tr>
          <td height="20"><blockquote>
            <p>Password</p>
          </blockquote></td>
          <td height="20"><label for="pass"></label>
            <input type="password" name="pass" id="pass" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td colspan="2" bgcolor="#0099FF"><div align="center">
            <h3>
              <input type="submit" name="ok" id="ok" value=" Login " />
              <input type="reset" name="no" id="no" value=" Cancel " />
            </h3>
          </div></td>
          </tr>
      </table></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</form>
<p>&nbsp;</p>
</body>
</html>
