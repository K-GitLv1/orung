<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/masterm60.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Untitled Document</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
<style type="text/css">
body,td,th {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 16px;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 16px;
}
a:link {
	text-decoration: none;
	color: #000;
}
a:visited {
	text-decoration: none;
	color: #000;
}
a:hover {
	text-decoration: none;
	color: #000;
}
a:active {
	text-decoration: none;
	color: #000;
}
</style>
</head>

<body>
<?php 
	session_start(); 
	if (!isset($_SESSION['session_user'])) {
		echo 'Please log in!.';
        header('refresh:2; login.html');
	}else{
?>
<table width="1200" border="1" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="180" colspan="3" bgcolor="#FF6633"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td height="150" colspan="2" bgcolor="#FF6600">&nbsp;</td>
            </tr>
          <tr>
            <td width="91%" height="30" bgcolor="#00CCFF"><blockquote>
              <p>ผู้ใช้งานในขณะนี้คือ : <!-- InstanceBeginEditable name="EditRegion3" --><!-- InstanceEndEditable --> </p>
            </blockquote></td>
            <td width="9%" height="30" bgcolor="#00CCFF"><a href="logout.php">Logout</a></td>
          </tr>
        </table></td>
        </tr>
      <tr>
        <td width="25%" height="500" valign="top" bgcolor="#CCCCCC"><table width="95%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="13%"><div align="center">&gt;&gt;</div></td>
            <td width="87%"><a href="home.php"> หน้าแรก</a></td>
          </tr>
          <tr>
            <td><div align="center">&gt;&gt;</div></td>
            <td><a href="menu1.php"> รายงานข้อมูล</a></td>
          </tr>
          <tr>
            <td><div align="center">&gt;&gt;</div></td>
            <td><a href="menu2.php">เพิ่มข้อมูล</a></td>
          </tr>
          <tr>
            <td><div align="center">&gt;&gt;</div></td>
            <td><a href="menu3.php">ลบข้อมูล</a></td>
          </tr>
          <tr>
            <td><div align="center">&gt;&gt;</div></td>
            <td><a href="menu4.php">แก้ไขข้อมูล</a></td>
          </tr>
          <tr>
            <td><div align="center">&gt;&gt;</div></td>
            <td><a href="menu5.php">ค้นหาข้อมูล</a></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table></td>
        <td width="50%" height="500" valign="top"><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="500" valign="top"><!-- InstanceBeginEditable name="EditRegion4" -->
              <h3 align="center">เพิ่มข้อมูล (MENU2.PHP)</h3>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
            <!-- InstanceEndEditable --></td>
          </tr>
        </table></td>
        <td width="25%" height="500" valign="top" bgcolor="#CCCCCC">&nbsp;</td>
      </tr>
      <tr>
        <td height="150" colspan="3" bgcolor="#FF6600"><div align="center">พัฒนาระบบโดย........................................<br />
          แผนกเทคโนโลยีสารสนเทศ วิทยาลัยเทคนิคอุดรธานี<br />
          E-mail : it.udontech.ac.th, Tel : 042-221538
        </div></td>
        </tr>
    </table></td>
  </tr>
</table>
<?php
}
?>
</body>
<!-- InstanceEnd --></html>
