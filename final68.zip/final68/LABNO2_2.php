<?php
include './dbcon.php'; // เชื่อมต่อฐานข้อมูล

// รับค่าจากฟอร์ม
$id = $_POST['id'];
$fname = $_POST['gender'];
$name = $_POST['name'];
$lname = $_POST['lname'];
$midt = $_POST['midt'];
$final = $_POST['final'];

// คำสั่ง SQL สำหรับเพิ่มข้อมูล
$sql = "INSERT INTO it53 (Id, fname, Name, lname, midt, final) 
        VALUES ('$id', '$fname', '$name', '$lname', $midt, $final)";

if ($connect->query($sql) === TRUE) {
    echo "บันทึกข้อมูลสำเร็จ!";
    header("Location: LABNO3.php");
} else {
    echo "ข้อผิดพลาด: " . $connect->error;
    header("refresh:2; home.php");
}

$connect->close(); // ปิดการเชื่อมต่อ
?>
