<?php
include './dbcon.php'; // เชื่อมต่อฐานข้อมูล

// รับค่า ID ที่จะถูกลบ
if (isset($_POST['id'])) {
    $id = $_POST['id'];

    // ลบข้อมูลจากฐานข้อมูล
    $delete_sql = "DELETE FROM it53 WHERE Id = '$id'";
    if (mysqli_query($connect, $delete_sql)) {
        echo "ลบข้อมูลเรียบร้อย!";
        header("Location: LABNO3.php"); // กลับไปที่หน้าหลัก
    } else {
        echo "เกิดข้อผิดพลาดในการลบข้อมูล!";
    }
}
?>
