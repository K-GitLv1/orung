<?php
// check_login.php
   session_start();
   $user = $_POST['user'];
   $pass = $_POST['pass']; 
    
   $c = strcasecmp("admin",$user);
   $p = strcasecmp("1234",$pass);
   //echo $c;
   //echo ("<br/>");
   
   if (($c==0)&&($p==0))
    {
        //echo "ผู้ใช้งานขณะนี้คือ : ".$user;
        $_SESSION['s_user'] = $user;
        header("Location: home.php");
    }else{
        echo "ชื่อหรือรหัสผ่านไม่ถูกต้อง !!";
        header('refresh:2; index.php');

    } 
?>