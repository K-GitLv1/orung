<?php
$host = "localhost";
//$user = "root";
//$password= "123456789";
//$database = "myphp"; 

$user = "66309010034db";
$password= "66309010034";
$database = "66309010034db"; 
 
$connect =  new mysqli($host,$user,$password,$database);
mysqli_set_charset($connect,"utf8mb4");  // แก้ปัญหาภาษาไทย ???
?>