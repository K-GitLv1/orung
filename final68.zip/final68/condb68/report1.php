<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>รายงานข้อมูล</title>
</head>
<body>
<?php
// File : report1.php
/*
$host = "localhost";
$user = "root";
$password= "123456789";
$database = "myphp"; 
 
$connect =  new mysqli($host,$user,$password,$database);
mysqli_set_charset($connect,"utf8mb4");  // แก้ปัญหาภาษาไทย ???
*/
include 'dbcon.php';  //file dbcon.php ไว้เชื่อมต่อกับฐานข้อมูล
$sqlshow = "SELECT * FROM lab1";  
$queryshow = $connect->query($sqlshow);
  if($queryshow->num_rows >0)
      {  
        while ($value = $queryshow->fetch_assoc())
        {
            echo " รหัส ";
            echo $no = $value['id'];
            echo "  ";
            echo $fname = $value['fname'];
            echo "  ";
            echo $lname = $value['lname'];
            echo '<br/>';
        }       
      }
?>
</body>
</html> 