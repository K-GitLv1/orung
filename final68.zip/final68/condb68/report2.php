<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>รายงานข้อมูล</title>
</head>
<body>
    <form id="form1" name="form1" method="post" action="">
</form>
<p>
<?php
	include 'dbcon.php';  //file dbcon.php ไว้เชื่อมต่อกับฐานข้อมูล
  $sqlshow = "SELECT * FROM lab1";  
  $queryshow = $connect->query($sqlshow);
?>
<table width="100%" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td bgcolor="#999999"><div align="center">รหัส</div></td>
    <td bgcolor="#999999"><div align="center">ชื่อ</div></td>
    <td bgcolor="#999999"><div align="center">สกุล</div></td>
  </tr>
<?php
  while ($value = $queryshow->fetch_assoc())
  {
     $id =  $value['id'];
     $fname = $value['fname'];
     $lname = $value['lname'];
   echo"  <tr>
      <td>$id</td>
      <td>$fname</td>
      <td>$lname</td>
      </tr>";
  }
  mysqli_close();   // ยกเลิกการเชื่อมต่อฐานข้อมูล
?>
</table>
</body>
</html>