<?php
    // logout.php :  ลบตัวแปร session
    session_start();
    session_destroy();
    header("Location:index.html");
?>
