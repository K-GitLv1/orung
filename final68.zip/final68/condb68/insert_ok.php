<?php 
    include 'dbcon.php';
    $std_id = $_REQUEST['std_id'];
    $std_fname = $_REQUEST['std_name'];
    $std_lname = $_REQUEST['std_surname'];
 
    $sql = "insert into lab1(id,fname,lname) 
            Values ('$std_id','$std_fname','$std_lname')";      
    if($connect->query($sql)===true)
        {
            echo "insert complete";
        }
    else {
            echo "Not insert";
        }        
?>
