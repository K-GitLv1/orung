<!DOCTYPE html>
<form action="insert_ok.php" method="post">
    <label>รหัสหัสนักศึกษา : </label>
    <input type="text" name="std_id"><p></p>
    <label>ชื่อ-สกุล : </label>
    <input type="text" name="std_name" >
    <input type="text" name="std_surname" ><p></p>
    <input type="submit" value = " บันทึกข้อมูล ">
    <input type="reset" value = " ยกเลิก ">
</form>