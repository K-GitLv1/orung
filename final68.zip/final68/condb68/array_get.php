<?php
// File : array_get.php
$no =  [
            ["1","สมชาย"],
            ["2","สมหญิง"],
            ["3","สมศักดิ์"],
        ];
for ($i = 0; $i<count($no); $i++) {
    echo $no[$i][0];
?>
   <a href="show_array_get.php?no=<?=$no[$i][0]?>"><?=$no[$i][1]?></a><br/>
<?php 
    } 
?>
