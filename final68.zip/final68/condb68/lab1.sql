-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 13, 2025 at 03:37 AM
-- Server version: 5.7.44-log
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `week6`
--

-- --------------------------------------------------------

--
-- Table structure for table `lab1`
--

CREATE TABLE `lab1` (
  `id` varchar(13) NOT NULL,
  `fname` varchar(40) DEFAULT NULL,
  `lname` varchar(40) DEFAULT NULL,
  `score` decimal(5,2) DEFAULT NULL,
  `bd` date DEFAULT NULL
) DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lab1`
--

INSERT INTO `lab1` (`id`, `fname`, `lname`, `score`, `bd`) VALUES
('65309010001', 'นายพิสิฐพงศ์', 'โภคชัย', '100.00', '2000-07-28'),
('65309010002', 'นายภูบดี', 'เศษชัง', '80.00', '2000-07-28'),
('65309010004', 'นายพุทธพร', 'วงษ์ไทย', '80.00', '2000-07-28'),
('65309010005', 'นายณัฐเมธี', 'พันธ์รังสิต', '80.00', '2010-05-03'),
('65309010006', 'นายเกียรติชัย', 'จันทร์แดง', '80.00', '2010-05-03'),
('65309010007', 'นายปวเรศ', 'พ่วงลาภหลาย', '80.00', '2010-05-03'),
('65309010008', 'นายกอบสุวรรณ', 'พุทธเสน', '80.00', '2010-05-03'),
('65309010009', 'นางสาวยลนภา', 'กันภัย', '80.00', '2010-05-03'),
('65309010010', 'นายภาณุวิชญ์', 'บุตตะวงษ์', '80.00', '2010-05-03'),
('65309010011', 'นางสาวหทัยรัตน์', 'ใจธรรม', '30.00', '2010-05-03'),
('65309010012', 'นายเจษฎาภรณ์', 'ลุพรมมา', '30.00', '2010-05-03'),
('65309010013', 'นายอัครวิชญ์', 'นิ่มศรีจันทร์', '30.00', '2010-05-03'),
('65309010014', 'นางสาวกุลปรียา', 'จันทร์ไพสนธ์', '30.00', '2010-05-03'),
('65309010015', 'นายจักรภัทร', 'พันชนกกุล', '30.00', '2010-05-03'),
('65309010020', 'นายจิรพนธ์', 'วงษ์คำ', '30.00', '2010-05-03'),
('65309010021', 'นายนวพล', 'ประเสริฐแท่น', '30.00', '2010-05-03'),
('65309010022', 'นายศุภวัฒน์', 'มาตย์เมือง', '30.00', '2010-05-03'),
('65309010065', 'นายคชาพัฒน์', 'แพร่สิริกุล', '30.00', '2010-05-03'),
('67319010019', 'นายรัฐภูมิ', ' นามบัวน้อย', '100.00', '2010-05-03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lab1`
--
ALTER TABLE `lab1`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
