<?php
   session_start();
?>   
<body text = "#0000FF">
<?php  
	if (!isset($_SESSION['s_user'])) {
		echo 'กรุณา Login เพื่อเข้าสู่ระบบ';
		header('refresh:2;login.php');
	}else{ 
?>        
<table width = "1240" height = "960" border = "0" cellpading = "0" cellspacing = "0" align = "center" >
<tr>
    <td valign="top" align = "center" >
        <table width = "100%" border = "0" cellpading = "0" cellspacing = "0" align = "center" >
            <tr height = "180">
               <td colspan="3" bgcolor = "#FFA500"><h1><p align = "center">PHP 2567</h1></td>             
               </td> 
            </tr>
            <tr height = "50" bgcolor = "#A9A9A9">
                <td width = "20%" align="center">ผู้ใช้งานขณะนี้คือ : <?php echo $_SESSION['s_user'];?> </td>         
                <td width = "60%"> </td>  
                <td width = "20%" align="center"><a href="logout.php">ออกจากระบบ</a></td>         
            </tr>
            <tr height = "600">
                <td width = "20%" bgcolor = "#D3D3D3" valign="top" >
                    <table align="center">                
                        <tr>
                            <td>หน้าแรก</td>
                        </tr>
                    </table>
                <td width = "60%" valign="top" align = "center"><h3>ข้อมูล</h3>
                <?php include 'report2.php';?>
                </td> 
                <td width = "20%" bgcolor = "#D3D3D3" valign="top">
                                                           
                </td> 
            </tr>
            <tr height = "180">
               <td colspan="3" bgcolor = "#A9A9A9"><h4><p align = "center">แผนกวิชาเทคโนโลยีสารสนเทศ<br/>
               วิทยาลัยเทคนิคอุดรธานี</h4></td>                 
            </tr>
        </table>   
    </td>
</tr>
</table>
<?php } ?>
</body>
