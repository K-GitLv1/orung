<form method="POST" action="check_login.php">
    Username : <input type="text" name = "user" /><p></p>  
    Password : <input type="password" name = "pass" /><p></p> 
    <input type = "submit" name = "yes" value = " Login ">
    <input type = "reset" name = "no" value = " Cancel ">
</form>