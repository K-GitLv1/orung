<?php
include './dbcon.php'; // เชื่อมต่อฐานข้อมูล

// ตรวจสอบว่าได้ส่งค่ามาหรือไม่
if (isset($_POST['id'])) {
    $id = $_POST['id'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $midt = $_POST['midt'];
    $final = $_POST['final'];

    // อัปเดตข้อมูลในฐานข้อมูล
    $update_sql = "UPDATE it53 SET fname='$fname', lname='$lname', midt='$midt', final='$final' WHERE Id='$id'";
    
    if (mysqli_query($connect, $update_sql)) {
        echo "อัปเดตข้อมูลเรียบร้อย!";
        header("Location: LABNO3.php"); // กลับไปที่หน้าหลัก
    } else {
        echo "เกิดข้อผิดพลาดในการอัปเดตข้อมูล!";
    }
} else {
    echo "กรุณากรอกข้อมูล";
}
?>
