<?php
session_start();

// ตรวจสอบว่าผู้ใช้เข้าสู่ระบบหรือไม่
if (!isset($_SESSION['username'])) {
    echo "กรุณาเข้าสู่ระบบก่อน!";
    echo "<br><a href='login.php'>เข้าสู่ระบบ</a>";
    exit();
}

echo "<h2>ยินดีต้อนรับ " . $_SESSION['name'] . "!</h2>";
echo "<p>ชื่อผู้ใช้: " . $_SESSION['username'] . "</p>";
echo "<br><a href='logout.php'>ออกจากระบบ</a>";
?>
