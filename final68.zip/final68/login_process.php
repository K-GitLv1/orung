<?php
session_start(); // เริ่มเซสชันเมื่อผู้ใช้เข้าสู่ระบบ

include './dbcon.php'; // เชื่อมต่อฐานข้อมูล

// รับค่าจากฟอร์ม
$username = $_POST['username'];
$password = $_POST['password'];

// ค้นหาข้อมูลในฐานข้อมูล
$sql = "SELECT * FROM users WHERE username = ? AND password = ?";
$stmt = $connect->prepare($sql);
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

// ตรวจสอบข้อมูล
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    
    // เก็บข้อมูลใน session
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['name'] = $user['name'];
    
    // เปลี่ยนไปที่หน้า home.php
    header("Location: home.php");
    exit();
} else {
    echo "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง!";
    echo "<br><a href='index.php'>ลองอีกครั้ง</a>";
}

$stmt->close();
$connect->close();
?>
