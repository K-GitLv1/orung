<?php
session_start(); // เริ่มเซสชันเพื่อเข้าถึงข้อมูลที่เก็บใน $_SESSION

// ตรวจสอบว่าผู้ใช้เข้าสู่ระบบหรือไม่
if (!isset($_SESSION['username'])) {
    header("Location: ./index.php"); // หากผู้ใช้ไม่ได้ล็อกอินให้ไปหน้า login
    exit();
}
?>
<header>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai&display=swap" rel="stylesheet">
    <div class="header-left">
        <h1>Final68_php</h1>
    </div>
    
    <nav>
        <ul>
            <li><a href="LABNO2_1.php">เพิ่มข้อมูลนักศึกษา</a></li>
            <li><a href="LABNO3.php">รายงานผลการเรียน</a></li>
            
        </ul>
    </nav>
    <div class="header-right">
        <p><?php echo $_SESSION['name']; ?>!</p>
        <a href="logout.php" class="logout">ออกจากระบบ</a>
    </div>
</header>
