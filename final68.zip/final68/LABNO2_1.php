
<head>
    <meta charset="UTF-8">
    <title>โปรแกรมบันทึกผลการเรียน</title>
    <link rel="stylesheet" href="./css/header.css"> <!-- ไฟล์ที่เกี่ยวกับ header -->
    <link rel="stylesheet" href="./css/main.css"> <!-- ไฟล์ที่เกี่ยวกับเนื้อหาหลัก -->
</head>
<body>
    <?php     require('./header.php'); ?>
    <div class="form-container"> <!-- ใช้ class สำหรับฟอร์ม -->
        <form action="LABNO2_2.php" method="post">
        <div class="card-header p-4">
                    <h2>โปรแกรมบันทึกผลการเรียน</h2>
                </div>
            
            <label>รหัสนักศึกษา: </label>
            <input type="text" name="id" required><br>
            

            <label>เพศ:</label><div>
            <input type="radio" name="gender" value="นาย" required> <span>ชาย</span>
            <input type="radio" name="gender" value="นางสาว" required> <span>หญิง</span><br>
</div>



            <label>ชื่อ:</label>
            <input type="text" name="name" required><br>

            <label>สกุล:</label>
            <input type="text" name="lname" required><br>

            <label>คะแนนระหว่างภาค: </label>
            <input type="number" name="midt" required><br>

            <label>คะแนนปลายภาค: </label>
            <input type="number" name="final" required><br>

            <button type="submit">บันทึกข้อมูล</button>
            <button type="reset">ยกเลิก</button>
        </form>
    </div>
</body>
